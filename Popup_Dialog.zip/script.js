const ShowPopupBTN = document.getElementById('ShowPopupBTN');
const CloseBTN = document.getElementById('CloseBTN');
const CancelBTN = document.querySelector('.CancelBTN');
const DialogPosition = document.getElementById('DialogPosition');

ShowPopupBTN.addEventListener('click', () => {
    DialogPosition.classList.add("DialogShow");
})

CloseBTN.addEventListener('click', () => {
    DialogPosition.classList.remove("DialogShow");
})

CancelBTN.addEventListener('click', () => {
    DialogPosition.classList.remove("DialogShow");
})